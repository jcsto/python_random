import re

"""
Author: Julio C Mesa

Goal: Scrape the TXT file and get the processor_name and the message
ignoring the brackets and the process_id column, but
including headers. Insert it into a new CSV file
"""
with open('test_parsed.csv', 'w+') as out, open('test.txt', 'r', encoding='utf-8') as orig_file:
    count = 0
    values = []
    for line in orig_file:
        count += 1

        if count == 1:
            values.append(re.sub('_', ' ', ','.join(['"' + val + '"' for val in line.split()[1:]])).upper())
            continue

        values.append(','.join(
            ['"' + v + '"' for v in re.split(
                ';', re.sub(";\s+", ';', re.split('\[', line)[0]).strip()
            )[1:]
             ]
        ))

    out.write('\r\n'.join(values))
